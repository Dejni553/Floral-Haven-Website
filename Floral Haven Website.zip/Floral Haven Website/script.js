// Show modal when Contact Us button is clicked
document.getElementById('contactButton').onclick = function() {
    document.getElementById('modal').style.display = 'block';
}

// Close the modal when clicking outside of it
window.onclick = function(event) {
    if (event.target == document.getElementById('modal')) {
        document.getElementById('modal').style.display = 'none';
    }
}
// Get the elements
const contactBtn = document.getElementById('contactBtn');
const contactBox = document.getElementById('contactBox');
const closeBtn = document.getElementById('closeBtn');

// Show the contact box when the button is clicked
contactBtn.addEventListener('click', () => {
    contactBox.style.display = 'block';
});

// Close the contact box when the close button is clicked
closeBtn.addEventListener('click', () => {
    contactBox.style.display = 'none';
});


   //Starts JavaScript for interactivity.
      document.addEventListener("DOMContentLoaded", () => { //Runs the script when the page loads.
        const contactButton = document.querySelector('a[href="#contact"]');//Selects the contact button.
        const contactBox = document.createElement("div"); //Creates a new div for the contact box.

        // Create the contact box content
        contactBox.className = "contact-box"; // Assigns a class to the div.
        contactBox.innerHTML = `
          <div class="contact-content">
            <h2>Contact Us</h2>
            <p>Email: info@floralhaven.com</p>
            <p>Phone: +355 123 456</p>
            <p>Follow us on:
              <a href="https://facebook.com" target="_blank">Facebook</a> |
              <a href="https://instagram.com" target="_blank">Instagram</a>
            </p>
            <button id="closeContact">Close</button>
          </div>
        `; // Adds content inside the contact box.
        document.body.appendChild(contactBox);

        // Show the contact box when the button is clicked
        contactButton.addEventListener("click", (e) => {
          e.preventDefault(); //Prevents the default link action.
          contactBox.style.display = "block"; //Makes the contact box visible
        });

        // Close the contact box when the close button is clicked
        const closeButton = contactBox.querySelector("#closeContact"); //Selects the close button.
        closeButton.addEventListener("click", () => { //Hides the contact box when clicked.
          contactBox.style.display = "none"; //Hides the contact box.
        });

        // Featured Flowers Gallery Navigation
        const gallery = document.getElementById('flowerGallery');
        const cards = gallery.querySelectorAll('.flip-card');
        const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const indicators = document.querySelectorAll('.indicator');
        
        let currentSlide = 0;
        const cardsPerSlide = 3;
        const totalSlides = Math.ceil(cards.length / cardsPerSlide);

        function showSlide(slideIndex) {
            // Hide all cards
            cards.forEach(card => card.style.display = 'none');
            
            // Show cards for current slide
            const startIndex = slideIndex * cardsPerSlide;
            const endIndex = Math.min(startIndex + cardsPerSlide, cards.length);
            
            for (let i = startIndex; i < endIndex; i++) {
                cards[i].style.display = 'block';
            }
            
            // Update indicators
            indicators.forEach(indicator => indicator.classList.remove('active'));
            indicators[slideIndex].classList.add('active');
            
            currentSlide = slideIndex;
        }

        function nextSlide() {
            const next = (currentSlide + 1) % totalSlides;
            showSlide(next);
        }

        function prevSlide() {
            const prev = (currentSlide - 1 + totalSlides) % totalSlides;
            showSlide(prev);
        }

        // Event listeners for arrows
        nextBtn.addEventListener('click', nextSlide);
        prevBtn.addEventListener('click', prevSlide);

        // Event listeners for indicators
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => showSlide(index));
        });

        // Auto-slide functionality
        setInterval(nextSlide, 5000); // Auto-advance every 5 seconds
      });
    

 