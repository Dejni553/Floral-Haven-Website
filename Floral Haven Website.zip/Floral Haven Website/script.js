// Show modal when Contact Us button is clicked
document.getElementById('contactButton').onclick = function() {
    document.getElementById('modal').style.display = 'block';
}

// Close the modal when clicking outside of it
window.onclick = function(event) {
    if (event.target == document.getElementById('modal')) {
        document.getElementById('modal').style.display = 'none';
    }
}
// Get the elements
const contactBtn = document.getElementById('contactBtn');
const contactBox = document.getElementById('contactBox');
const closeBtn = document.getElementById('closeBtn');

// Show the contact box when the button is clicked
contactBtn.addEventListener('click', () => {
    contactBox.style.display = 'block';
});

// Close the contact box when the close button is clicked
closeBtn.addEventListener('click', () => {
    contactBox.style.display = 'none';
});

document.addEventListener("DOMContentLoaded", () => {
    const cards = document.querySelectorAll(".flip-card"); // Grab all cards
    let currentCardIndex = 0; // Starting card index

    const arrowLeft = document.querySelector(".arrow-left"); // Left arrow
    const arrowRight = document.querySelector(".arrow-right"); // Right arrow

    // Function to show the current card based on index
    function showCard(index) {
        // Hide all cards
        cards.forEach(card => card.style.display = "none");
        // Show the current card
        cards[index].style.display = "block";
    }

    // Event listener for left arrow
    arrowLeft.addEventListener("click", () => {
        currentCardIndex--; // Move to the previous card
        if (currentCardIndex < 0) {
            currentCardIndex = cards.length - 1; // Loop back to the last card
        }
        showCard(currentCardIndex);
    });

    // Event listener for right arrow
    arrowRight.addEventListener("click", () => {
        currentCardIndex++; // Move to the next card
        if (currentCardIndex >= cards.length) {
            currentCardIndex = 0; // Loop back to the first card
        }
        showCard(currentCardIndex);
    });

    // Initially show the first card
    showCard(currentCardIndex);
});

 